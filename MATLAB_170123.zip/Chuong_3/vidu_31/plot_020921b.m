clc;
t = speed.time;
speed_ref = speed.signals.values(:,1);
speed_real = speed.signals.values(:,2);
plot(t,speed_ref,'k--','linewidth',1.5);
hold on;
plot(t,speed_real,'k-','linewidth',1.5);
axis([0 max(t) 1.2*min(speed_real) 1.2*max(speed_real)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('n (vong/phut)');
legend('Toc do tham chieu','Toc do thuc');



