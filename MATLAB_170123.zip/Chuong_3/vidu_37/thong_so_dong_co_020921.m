clc;                    % Xoa thong tin Command Window
clear;                  % Xoa thong tin Workspace
% Thong so cua dong co:
Ra = 7.55;              % Dien tro phan (Ohm)
La = 0.1114;            % Dien cam phan ung (H)
Re = 240;               % Dien tro kich tu (Ohm)
Le = 120;               % Dien cam kich tu (H)
Me = 1.8;               % Ho cam phan ung va kich tu (H)
K = 1.6504;             % Hang so dong co (V/rad/s)
Ve = 220;               % Dien ap kich tu (V)
J = 0.01287;            % Mo men quan tinh (kg.m^2)
B = 0.00001;            % He so ma sat (N.m.s)
TL = 5;       
% Thong so buck converter:
E = 220;                % Dien ap nguon xoay chieu (V)
f = 1000;               % Tan so bam xung (Hz)
L = 0.01;               % Dien cam (H)
C = 1000e-6;            % Tu dien (F)
% Thong so bo uoc luong toc do:
Ts = 1e-4;              % Thoi gian lay mau (giay)
a1 = J/(J + Ts*B);
a2 = Ts*K/(J + Ts*B);
a3 = -Ts/(J + Ts*B);
% Thong so bo dieu khien PI dong dien:
Kp = 0.25;              % Hang so ty le
Ki = 0.1;               % Hang so tich phan