clc;                    % Xoa thong tin Command Window 
clear;  				% Xoa thong tin Workspace
% Thong so cua dong co:
Ra = 7.55;              % Dien tro phan (Ohm)
La = 0.1114;            % Dien cam phan ung (H)
Re = 240;               % Dien tro kich tu (Ohm)
Le = 120;               % Dien cam kich tu (H)
Me = 1.8;               % Ho cam phan ung va kich tu (H)
K = 1.6504;             % Hang so dong co (V/rad/s)
Ve = 220;               % Dien ap kich tu (V)
J = 0.01287;            % Mo men quan tinh (kg.m^2)
b = 0.00001;            % He so ma sat (N.m.s)
TL = 10;                % Mo men tai (N.m)       
% Thong so bo bam xung noi tiep:
E = 220;                % Dien ap nguon xoay chieu (V)
f = 1000;               % Tan so bam xung (Hz)
% Ma tran cua mo hinh khong gian trang thai cua dong co:
A = [-b/J K/J; -K/La -Ra/La];
B = [0; 1/La];
C = [1 0];
D = [];
% Cac ma tran cua mo hinh khong gian trang thai voi bien w(t):
Aa = [-b/J K/J 0; -K/La -Ra/La 0; 1 0 0];
Ba = [0; 1/La; 0];
Br = [0; 0; -1];
Ca = [1 0 0];
Da = [];
p1 = -200 + 20i;            % Gan cuc thu nhat
p2 = -200 - 20i;          	% Gan cuc thu hai
p3 = -200;                	% Gan cuc thu ba
Ka = place(Aa,Ba,[p1, p2, p3]); % Ma tran phan hoi bien trang thai
% Thiet ke bo quan sat 
op1 = -300;
op2 = -350;
L = place(A',C',[op1 op2])';  
% Thong so bo dieu khien PD:
Kp = 1;                 % He so ty le
Kd = 10;                % He so vi phan
N = 1000;               % He so bo loc