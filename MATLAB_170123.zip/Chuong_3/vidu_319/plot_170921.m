clc;
t = speed.time;
n1 = speed.signals.values(:,1);
n2 = speed.signals.values(:,2);
n2_final = n2(end);
plot(t,n1,'k--','linewidth',1.5);
hold on;
plot(t,n2,'k-','linewidth',1.5);
xlabel('Thoi gian (s)');
ylabel('Toc do (vong/phut)');
axis([0 max(t) 0 1.25*max(n2)]);
grid;
legend('Toc do tham chieu','Toc do dong co');
sys_info = stepinfo(n2,t,n2_final,...
                    'RiseTimeLimits',[0.1,0.95],...
                    'SettlingTimeThreshold',0.01);
Mp = sys_info.Overshoot;
Tp = sys_info.PeakTime;
Tr = sys_info.RiseTime;
Ts = sys_info.SettlingTime;
Mp_Tp_Tr_Ts = [Mp Tp Tr Ts]
