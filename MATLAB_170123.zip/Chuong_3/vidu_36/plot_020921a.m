clc;
t = speed.time;
n_ref = speed.signals.values(:,1);
n_real = speed.signals.values(:,2);
n_est = speed.signals.values(:,3);
plot(t,n_ref,'k--','linewidth',1.5);
hold on;
plot(t,n_real,'k-','linewidth',1.5);
hold on;
plot(t,n_est,'k:','linewidth',1.5);
axis([0 max(t) 0 1.4*max(n_ref)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('n (vong/phut)');
legend('Toc do tham chieu','Toc do thuc','Toc do uoc luong');


