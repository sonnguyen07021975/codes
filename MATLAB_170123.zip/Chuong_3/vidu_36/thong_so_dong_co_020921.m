clc;                    % Xoa thong tin Command Window
clear;                  % Xoa thong tin Workspace
% Thong so dong co:
Va = 220;               % Dien ap phan ung (V)
Ra = 7.55;              % Dien tro phan (Ohm)
La = 0.1114;            % Dien cam phan ung (H)
Re = 240;               % Dien tro kich tu (Ohm)
Le = 120;               % Dien cam kich tu (H)
Me = 1.8;               % Ho cam phan ung va kich tu (H)
K = 1.6504;               % Hang so dong co (V/rad/s)
J = 0.01287;            % Mo men quan tinh (kg.m^2)
B = 0.00001;            % He so ma sat (N.m.s)
TL = 5;                % Mo men tai (N.m)
Ts = 1e-4;              % Thoi gian lay mau (giay)
% Thong so bo bam:
E = 220;                % Dien ap nguon xoay chieu (V)
f = 1000;               % Tan so nguon xoay chieu (Hz)
% Thong so bo uoc luong toc do:
a1 = J/(J + Ts*B);
a2 = Ts*K/(J + Ts*B);
a3 = -Ts/(J + Ts*B);
% Thong so bo dieu khien PI toc do:
Kp = 10;                % He so ty le 
Ki = 0.1;               % He so tich phan