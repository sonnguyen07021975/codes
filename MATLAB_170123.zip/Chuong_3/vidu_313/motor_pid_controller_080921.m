clc;                       % Xoa thong tin Command Window
clear;                     % Xoa thong tin Workspace
% Thong so dong co:
Ra = 7.55;                 % Dien tro phan (Ohm)
La = 0.1114;               % Dien cam phan ung (H)
K = 1.6504;                % Hang so dong co (V/rad/s)
J = 0.01287;               % Mo men quan tinh (kg.m^2)
B = 0.00001;               % He so ma sat (N.m.s)
% Tinh toan ham truyen cua dong co:
num = K/La/J;
a2 = 1;
a1 = (La*B+Ra*J)/La/J;
a0 = (Ra*B+K*K)/La/J;
den = [a2 a1 a0];
G1s = tf(num,den);   % Ham truyen dong co o dang toan tu s
% Dap ung toc do voi bo dieu khien PID:
Kp = 0.1;            % He so ty le
Ki = 50;             % He so tich phan
Kd = 2.5;            % He so vi phan
N = 1;            % He so bo loc
Ds = tf([Kp+Kd*N Kp*N+Ki Ki*N],[1 N 0]); % Ham truyen bo dieu khien PID
G2s = feedback(Ds*G1s,1);
t = 0:0.001:0.5;
y = step(G2s,t);
plot(t,y,'k-','linewidth',1.5);
grid on;
xlabel('Thoi gian (s)');
ylabel('Toc do (rad/s/V)');
% Thong so ky thuat mien thoi gian:
Kdc = dcgain(G2s);       % He so khuyech dai DC
gamma = 0.02;            % Dai gia tri xac lap
info_tf = stepinfo(G2s,'RiseTimeLimits',[0,0.99],...
                    'SettlingTimeThreshold',gamma);
Mp = info_tf.Overshoot;       % Do qua hieu chinh (%)
Tp = info_tf.PeakTime;        % Thoi gian dinh (s)
Tr = info_tf.RiseTime;        % Thoi gian tang (s)
Ts = info_tf.SettlingTime;    % Thoi gian on dinh (s)
poles = pole(G1s);
Kdc_Mp_Tp_Tr_Ts = [Kdc Mp Tp Tr Ts]