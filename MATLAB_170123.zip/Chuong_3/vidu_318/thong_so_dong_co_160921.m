clc;                    % Xoa thong tin Command Window 
clear;  				% Xoa thong tin Workspace
% Thong so cua dong co:
Ra = 7.55;              % Dien tro phan (Ohm)
La = 0.1114;            % Dien cam phan ung (H)
Re = 240;               % Dien tro kich tu (Ohm)
Le = 120;               % Dien cam kich tu (H)
Me = 1.8;               % Ho cam phan ung va kich tu (H)
K = 1.6504;             % Hang so dong co (V/rad/s)
Ve = 220;               % Dien ap kich tu (V)
J = 0.01287;            % Mo men quan tinh (kg.m^2)
b = 0.00001;            % He so ma sat (N.m.s)
TL = 5;       
% Thong so bo bam xung noi tiep:
E = 220;                % Dien ap nguon xoay chieu (V)
f = 1000;               % Tan so bam xung (Hz)
% Mo hinh khong gian trang thai:
A = [-b/J K/J; -K/La -Ra/La];
B = [0; 1/La];
C = [1 0];
D = [];
sys = ss(A,B,C,D);
poles = pole(sys);          % Cac cuc cua he ho
p1 = -200+20j;              % Gan cuc thu nhat
p2 = -200-20j;              % Gan cuc thu hai
Kc = place(A,B,[p1 p2]);    % Vec to he so phan hoi bien trang thai
sys_cl = ss(A-B*Kc,B,C,D);  % Mo hinh khong gian trang thai he kin
t = 0:0.001:0.5;
y = step(sys_cl,t);         % Dap ung dau ra
y_final = y(end);           % Gia tri dau ra xac lap      
Nbar = 1/y_final;           % He so khau bu truoc
plot(t,Nbar*y,'k-','linewidth',1.5);
xlabel('Thoi gian (s)');
ylabel('Toc do (rad/s)');
grid;
op1 = -250;
op2 = -300;
L = place(A',C',[op1 op2])';

