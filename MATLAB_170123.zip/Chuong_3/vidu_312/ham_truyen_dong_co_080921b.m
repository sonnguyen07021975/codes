clc;                            % Xoa thong tin Command Window
clear;                          % Xoa thong tin Workspace
% Thong so dong co:
Ra = 7.55;                      % Dien tro phan (Ohm)
La = 0.1114;                    % Dien cam phan ung (H)
K = 1.6504;                     % Hang so dong co (V/rad/s)
J = 0.01287;                    % Mo men quan tinh (kg.m^2)
B = 0.00001;                    % He so ma sat (N.m.s)
% Tinh toan ham truyen cua dong co:
num = K/La/J;
a2 = 1;
a1 = (La*B+Ra*J)/La/J;
a0 = (Ra*B+K*K)/La/J;
den = [a2 a1 a0];
G1s = tf(num,den); % Ham truyen cua dong co
t = 0:0.001:0.5;
y = step(G1s,t);
plot(t,y,'k-','linewidth',1.5);
grid on;
Kdc = dcgain(G1s);                  % He so khuyech dai DC
omega_n = sqrt(den(3));             % Tan so dao dong khong tat dan
ci = den(2)/2/omega_n;              % He so tat dan
Mp = exp(-(ci*pi/sqrt(1-ci^2)));    % Qua hieu chinh
omega_d = omega_n*sqrt(1 - ci^2);   % Tan so tat dan
Tp = pi/omega_d;                    % Thoi gian dinh
beta = atan(sqrt(1-ci^2)/ci);
Tr = (pi - beta)/omega_n/sqrt(1-ci^2); % Thoi gian tang
gamma = 0.02;                          % Sai so toc do
Ts = -log(gamma)/ci/omega_n;           % Thoi gian xac lap
poles = pole(G1s)
Kdc_Mp_Tp_Tr_Ts = [Kdc Mp*100 Tp Tr Ts]
