clc;
t = speed1.time;
n = speed1.signals.values(:,2);
n_final = n(end);
plot(t,n,'k-','linewidth',1.5);
xlabel('Thoi gian (s)');
ylabel('Toc do (vong/phut)');
axis([0 max(t) 0 1.1*max(n)]);
grid on;
sys_info = stepinfo(n,t,n_final,...
                    'RiseTimeLimits',[0,1],...
                    'SettlingTimeThreshold',0.01);
Mp = sys_info.Overshoot;
Tp = sys_info.PeakTime;
Tr = sys_info.RiseTime;
Ts = sys_info.SettlingTime;
Mp_Tp_Tr_Ts = [Mp Tp Tr Ts]
