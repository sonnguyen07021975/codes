clc;                    % Xoa thong tin Command Window
clear;                  % Xoa thong tin Workspace
% Thong so tai:
Ra = 7.55;              % Dien tro tai (Ohm)
La = 0.1114;            % Dien cam tai (H)
% Thong so buck converter:
E = 220;                % Dien ap nguon xoay chieu (V)
f = 1000;               % Tan so cua bo bien doi (Hz)
L = 2;                  % Dien cam bo bien doi (H)
C = 1000e-6;            % Tu dien bo bien doi (F)
gamma = 0.8;            % Ty so chu ky


