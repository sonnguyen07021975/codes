clc;                    % Xoa thong tin Command Window
clear;                  % Xoa thong tin Workspace
% Thong so dong co:
Ra = 7.55;              % Dien tro phan (Ohm)
La = 0.1114;            % Dien cam phan ung (H)
Re = 240;               % Dien tro kich tu (Ohm)
Le = 120;               % Dien cam kich tu (H)
Me = 1.8;               % Ho cam phan ung va kich tu (H)
K = 1.6504;             % Hang so dong co (V/rad/s)
Ve = 220;               % Dien ap kich tu (V)
J = 0.01287;            % Mo men quan tinh (kg.m^2)
B = 0.00001;            % He so ma sat (N.m.s)
TL = 5;                 % Momen tai (N.m)
% Thong so bo bam:
E = 220;                % Dien ap nguon mot chieu (V)
f = 1000;               % Tan so bam xung (Hz)
% Tinh toan thong so ham truyen cua dong co:
Ts = 0.01;              % Chu ky lay mau (giay)
num = [K];
a2 = La*J;
a1 = La*B+Ra*J;
a0 = Ra*B+K*K;
den = [a2 a1 a0];
G1s = tf(num,den);          % Ham truyen dong co o dang to�n tu s
G1Hz = c2d(G1s,Ts,'ZOH');   % Ham truyen dong co o dang bien doi z v� ZOH
G2z = tf([1],[1 0],Ts);
Dz = (G2z/(1-G2z))/G1Hz    % Ham truyen cua bo dieu khien dead-beat
[num1,den1] = tfdata(Dz);
num1 = num1{1,1};           % Tu so cua ham truyen bo dieu khien
b2 = num1(1);
b1 = num1(2);
b0 = num1(3);
den1 = den1{1,1};           % Mau so cua ham truyen bo dieu khien
c2 = den1(1);
c1 = den1(2);
c0 = den1(3);
