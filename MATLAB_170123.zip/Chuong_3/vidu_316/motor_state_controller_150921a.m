clc;                    % Xoa thong tin Command Window 
clear;  				% Xoa thong tin Workspace
% Thong so dong co:
Ra = 7.55;              % Dien tro phan (Ohm)
La = 0.1114;            % Dien cam phan ung (H)
K = 1.6504;             % Hang so dong co (V/rad/s)
J = 0.01287;            % Mo men quan tinh (kg.m^2)
b = 0.00001;            % He so ma sat (N.m.s)
% Mo hinh khong gian trang thai:
A = [-b/J K/J; -K/La -Ra/La];
B = [0; 1/La];
C = [1 0];
t = 0:0.001:0.5;
p1 = -200 + 20i;          % Gan cuc thu nhat
p2 = -200 - 20i;          % Gan cuc thu hai
Kc = place(A,B,[p1, p2]); % Ma tran phan hoi bien trang thai
sys_cl = ss(A-B*Kc,B,C,[]);
y = step(sys_cl,t);
plot(t,y,'k-','linewidth',1.5);
axis([0 max(t) 0 1.1*max(y)]);
xlabel('Thoi gian (s)');
ylabel('Toc do (rad/s)');
grid;
y_final = y(end);
sys_info = stepinfo(y,t,y_final,'RiseTimeLimits',[0,1],...
                    'SettlingTimeThreshold',0.01);
Mp = sys_info.Overshoot;     % Do qua hieu chinh (%)
Tp = sys_info.PeakTime;      % Thoi gian dinh (giay)
Tr = sys_info.RiseTime;      % Thoi gian tang (giay)
Ts = sys_info.SettlingTime;  % Thoi gian on dinh (giay)
Mp_Tp_Tr_Ts = [Mp Tp Tr Ts]