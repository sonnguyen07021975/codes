clc;
t = speed.time;
ref_speed = speed.signals.values(:,1);
real_speed = speed.signals.values(:,2);
estimated_speed = speed.signals.values(:,3);
plot(t,ref_speed,'k:','linewidth',1.5);
grid on;
hold on;
plot(t,real_speed,'k-','linewidth',1.5);
grid on;
hold on;
plot(t,estimated_speed,'k--','linewidth',1.5);
xlabel('Thoi gian (s)');
ylabel('n (vong/phut)');
axis([0 max(t) 0 1.7*max(real_speed)]);
legend('Toc do tham chieu','Toc do thuc','Toc do uoc luong');


