clc;                    % Xoa thong tin Command Window
clear;                  % Xoa thong tin Workspace
% Thong so tai:
R = 7.55;               % Dien tro phan (Ohm)
L = 0.1114;             % Dien cam phan ung (H)
% Thong so bo bam:
E = 220;                % Dien ap nguon xoay chieu (V)
f = 1000;               % Tan so bam (Hz)
Ts = 1/f;               % Chu ky bam (giay)
gamma = 30;             % Ty so chu ky (%)
