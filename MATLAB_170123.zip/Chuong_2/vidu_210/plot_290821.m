clc;                            % Xoa thong tin Command Window
t = V.time;                     % Vecto thoi gian (giay)
V1 = V.signals.values;          % Vecto dien ap tai (V)
I1 = I.signals.values;          % Vecto dong dien tai (A)
plot(t,V1,'k-','linewidth',1.5);
xlabel('Thoi gian (s)');
ylabel('V (V)/I (A)');
axis([0 max(t) 1.2*min(V1) 1.2*max(V1)]);
grid on;
hold on;
plot(t,I1,'k--','linewidth',1.5);
legend('Dien ap tai','Dong dien tai');