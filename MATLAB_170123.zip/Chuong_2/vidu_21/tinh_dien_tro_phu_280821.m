clc;                            % Xoa thong tin Command Window
clear;                          % Xoa thong tin Workspace
Va = 220;                       % Dien ap phan ung (V)
Ra = 7.55;                      % Dien tro phan (Ohm)
K = 0.8704;                     % Hang so dong co (V/rad/s)
n = 1200;                       % Toc do dong co (vong/phut)
omega = n*pi/30;                % Toc do dong co (rad/s)
TL = 3.5;                       % Mo men tai (N.m)
Rf = (Va - K*omega)*K/TL - Ra;  % Dien tro phu (Ohm)