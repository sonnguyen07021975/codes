clc;                    % Xoa thong tin Command Window
clear;                  % Xoa thong tin Workspace
% Thong so dong co:
Ra = 7.55;              % Dien tro phan (Ohm)
La = 0.1114;            % Dien cam phan ung (H)
Re = 240;               % Dien tro kich tu (Ohm)
Le = 120;               % Dien cam kich tu (H)
Me = 1.8;               % Ho cam phan ung va kich tu (H)
J = 0.01287;            % Mo men quan tinh (kg.m^2)
B = 0.00001;            % He so ma sat (N.m.s)
TL = 5;                 % Momen tai (N.m)
% Thong so bo chinh luu:
Vs = 220;               % Dien ap nguon xoay chieu (V)
f = 50;                 % Tan so nguon xoay chieu (Hz)
alpha = 0.01/2;         % Goc mo cua cac tiristo (giay)
