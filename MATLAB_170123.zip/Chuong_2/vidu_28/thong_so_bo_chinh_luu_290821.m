clc;                % Xoa thong tin Command Window
clear;              % Xoa thong tin Workspace
R = 7.55;           % Dien tro tai (Ohm)
L = 0.1114;         % Dien cam tai (H)
Vs = 220;           % Dien ap pha cua nguon (V)
f = 50;             % Tan so nguon (Hz)
alpha = 0.01/2;     % Goc mo cua tiristo (giay)