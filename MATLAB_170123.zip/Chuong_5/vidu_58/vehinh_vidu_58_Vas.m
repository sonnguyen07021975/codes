
clc;
clear;
load Vab.mat;
t1 = Vab(1,:);
y1 = Vab(2,:);
plot(t1, y1,'k','linewidth',2);
xlabel('(Giay)');
ylabel('V�n');
axis([7.95 7.96 -600 600]);
legend('Dien ap day A','Location','northwest');
grid on;
%--------------------------------------------------------------%
