
clc;
clear;

load Flux_m.mat;
load Psi_S.mat;

t1 = Flux_m(1,:);
y1 = Flux_m(2,:);
plot(t1, y1,'k','linewidth',2);
hold on;

t2 = Psi_S(1,:);
y2 = Psi_S(2,:);
plot(t2, y2,'k--','linewidth',3.0);
xlabel('(Giay)');
ylabel('Wb');
axis([0.1 8 0 2]);
legend('Tu thong Do luong','Tu thong uoc luong','Location','northwest');
grid on;
%--------------------------------------------------------------%
