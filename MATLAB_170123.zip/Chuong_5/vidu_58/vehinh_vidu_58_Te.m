
clc;
clear;

load Te2.mat;
load Te_es.mat;

t1 = Te2(1,:);
y1 = Te2(2,:);
plot(t1, y1,'k','linewidth',2);
hold on;

t2 = Te_es(1,:);
y2 = Te_es(2,:);
plot(t2, y2,'k--','linewidth',3.0);
xlabel('(Giay)');
ylabel('Nm');
axis([1.1 1.103 4 6]);
legend('Mo men do luong','Mo men dien tu uoc luong','Location','northwest');
grid on;
%--------------------------------------------------------------%
