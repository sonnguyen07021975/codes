
clc;
clear;

load w_ref.mat;
load wr.mat;

t1 = w_ref(1,:);
y1 = w_ref(2,:);
plot(t1, y1,'k','linewidth',2.0);
hold on;

t2 = wr(1,:);
y2 = wr(2,:);
plot(t2, y2,'k--','linewidth',3.0);
xlabel('(Giay)');
ylabel('Rad/giay');
axis([0.1 8 -20 20]);
legend('Toc do dat','Toc do thuc','Location','northwest');
grid on;
%--------------------------------------------------------------%
