
clc;
clear;

load i_a.mat;

t1 = i_a(1,:);
y1 = i_a(2,:);
plot(t1, y1,'k','linewidth',1);
xlabel('(Giay)');
ylabel('A');
axis([0.1 8 -10 10]);
legend('Dong dien pha A','Location','northwest');
grid on;
%--------------------------------------------------------------%
