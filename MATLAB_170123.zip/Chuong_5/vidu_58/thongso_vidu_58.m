clc;
clear;
%% Motor parameters
Ts = 1e-5;                      % Sampling Time (sec)
Vdc = 500;
Pn = 2200;                      % Motor power (2200 W)
Vn = 380;                       % Line to line voltage (V)
fn = 50;                        % Frequency (Hz)
Rc = 0.0;
p = 1;                          % Number of pole pairs
Rs = 1.99;                      % Stator resistance (Ohms)
Rr = 1.84;                      % Rotor resistance (Ohms)
Lls = 0.01;                      % Stator leakage inductance (H)
Llr = 0.01;                      % Stator leakage inductance (H)
Lm = 0.37;                      % Mutual Inductance (H)
Ls = Lm + Lls;                  % Stator self inductance (H)
Lr = Lm + Llr;                  % Rotor self inductance (H)
J = 0.002159;                       % Inertia(kg.m^2)
F = 0;                      % Friction factor (N.m.s)
ci = 1 - (Lm^2/Lr/Ls);
Tm = 5;                       % Load Torque (N.m)
Tr = Lr/Rr;
Kp= 1;
Ki=10;