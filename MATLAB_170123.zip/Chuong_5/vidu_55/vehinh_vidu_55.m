
clc;
clear;
load Te.mat;
load Iabc.mat;
load Vab.mat;
load speed_ac.mat;
load speed_ref.mat;

t1 = Te(1,:);
y1 = Te(2,:);
plot(t1, y1,'m','linewidth',2);
xlabel('timer (sec)');
ylabel('N.m');
axis([0.02 max(t1) -8 8]);
legend('induction motor Momen');
grid on;
pause;
close;

t2 = Iabc(1,:);
y2 = Iabc(2,:);
plot(t2, y2,'b','linewidth',2);
xlabel('(giay)');
ylabel('Ampe');
axis([0.02 max(t2) -10 10]);
legend('induction motor current');
grid on;
pause;
close;

t3 = Vab(1,:);
y3 = Vab(2,:);
plot(t3, y3,'r','linewidth',2);
xlabel('(timer (sec))');
ylabel('Volt');
axis([0.02 max(t3) -600 600]);
legend('induction motor voltage');
grid on;
pause;
close;

t4 = speed_ac(1,:);
y4 = speed_ac(2,:);
plot(t4, y4,'b','linewidth',3);
xlabel('timer (sec)');
hold on;
t5 = speed_ref(1,:);
y5 = speed_ref(2,:);
plot(t5, y5,'r--','linewidth',2.5);
xlabel('(sec)');
ylabel('RPM');
axis([0.02 max(t5) -500 500]);
legend('actual speed','reference speed');
grid on;
pause;
close;
