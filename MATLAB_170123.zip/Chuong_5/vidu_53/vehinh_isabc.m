clc;
clear;

load is_a.mat;
load is_b.mat;
load is_c.mat;

x1 = is_a.time;
y1 = is_a.data;
plot(x1,y1,'k','linewidth',1);
hold on;
x2 = is_b.time;
y2 = is_b.data;
plot(x2,y2,'b','linewidth',1);
hold on;

x3 = is_c.time;
y3 = is_c.data;
plot(x3,y3,'r','linewidth',1);
hold on;

xlabel('giay');
ylabel('Dong dien(A)');
axis([0 1.5 -50 50]);
legend('ia','ib','ic');
grid on;