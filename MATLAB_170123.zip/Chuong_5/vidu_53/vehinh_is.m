clc;
clear;
load Is.mat;
t1 = Is(1,:);
y1 = Is(2,:);
plot(t1, y1,'k-','linewidth',2.5);
xlabel('(Giay)');
ylabel('I(A), Bien do dong dien');
axis([1.45 1.5 2 3]);
grid on;
%--------------------------------------------------------------%
