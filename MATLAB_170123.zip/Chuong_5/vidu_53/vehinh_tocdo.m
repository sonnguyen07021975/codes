clc;
clear;
load speed.mat;

t1 = speed(1,:);
y1 = speed(2,:);
plot(t1, y1,'k','linewidth',2.0);
xlabel('(Giay)');
ylabel('Toc do(Rad/giay)');
axis([0 1.5 0 350]);
legend('Toc do dong co');
grid on;