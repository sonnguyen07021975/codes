clc;
clear;
load Te.mat;

t1 = Te(1,:);
y1 = Te(2,:);
plot(t1, y1,'k','linewidth',2.0);
xlabel('(Giay)');
ylabel('(Nm)');
axis([0 1.5 -20 20]);
legend('Mo men dien tu cua dong co');
grid on;