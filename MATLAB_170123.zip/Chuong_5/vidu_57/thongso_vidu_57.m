clc;
clear;
%% Motor parameters
Ts = 1e-5;                  % Sampling Time (sec)
Pn = 2*736;                 % Motor power (1492 W-2HP)
Vn = 380;                   % Line to line voltage (V)
fn = 50;                    % Frequency (Hz)
Rs = 10;                    % Stator resistance (Ohms)
Lls = 0.04;                 % Stator leakage inductance (H)
Rr = 6.3;                   % Rotor resistance (Ohm)
Llr = 0.04;                 % Rotor leakage inductance (H)
Lm = 0.42;                  % Mutual Inductance (H)
Ls = Lm + Lls;              % Stator self inductance (H)
Lr = Lm + Llr;              % Rotor self inductance (H)
J = 0.03;                   % Inertia(kg.m^2)
F = 0.0;                 % Friction factor (N.m.s)
p = 2; 
P=4;
% Number of pole pairs
Tr = Lr/Rr;                 % Time Constant of flux (second
sigma = 1-Lm^2/(Ls*Lr);
Vdc = 500;                  % Bus DC Voltage (V)