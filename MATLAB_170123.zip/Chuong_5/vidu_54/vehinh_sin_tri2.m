
clc;
clear;

load V_control.mat;
load V_tri.mat;
load V_AN.mat;

t1 = V_control(1,:);
y1 = V_control(2,:);
plot(t1, y1,'k--','linewidth',2);
hold on;

t2 = V_tri(1,:);
y2 = V_tri(2,:);
plot(t2, y2,'k:.','linewidth',2);
hold on;

xlabel('(Giay)');
ylabel('V');
axis([0 0.02 -15 15]);
legend('Song sin-dieu khien','Song mang- Tam giac','Location','northwest');
grid on;
%--------------------------------------------------------------%
