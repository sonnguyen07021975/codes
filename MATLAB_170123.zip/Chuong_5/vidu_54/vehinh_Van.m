
clc;
clear;

load V_AN.mat;

t1 = V_AN(1,:);
y1 = V_AN(2,:);
plot(t1, y1,'k','linewidth',2.5);

xlabel('(Giay)');
ylabel('V');
axis([0 0.1 -400 400]);
legend('Dien ap pha A','Location','northwest');
grid on;
%--------------------------------------------------------------%
