clc;                
clear;              
Pn = 2200;
Vn = 400;        
nn = 2880;
p = 1;
fn = 50;            
Rs = 1.99;           
Rr = 1.84;           
Lls = 0.0111;       
Llr = 0.0115;   
Lm = 0.369;    
Ls = Lm+Lls;  
Lr = Lm+Llr;  
J = 0.002159;  
B = 0;            
TL = 5.5;       
Ts = 0.00001;
Xs = 2*pi*fn*Lls;
Xr = 2*pi*fn*Llr;
Vs = 231;
p1 = 1;           % So doi cuc p1
p2 = 2;           % So doi cuc p2
p3 = 3;           % So doi cuc p3
n1 = 60*fn/p1;       
n2 = 60*fn/p2;       
n3 = 60*fn/p3;       
omega1 = n1*pi/30;
omega2 = n2*pi/30; 
omega3 = n3*pi/30; 
omega = 0:1:350;
s1 = (omega1 - omega)/omega1;
s2 = (omega2 - omega)/omega2;
s3 = (omega3 - omega)/omega3;
omega11 = (1 - s1)*omega1;
omega22 = (1 - s2)*omega2;
omega33 = (1 - s2)*omega3;
T1 = (3/omega1)*(Vs^2*Rr./s1)./...
         ((Rs + Rr./s1).^2 + (Xs + Xr)^2);
T2 = (3/omega2)*(Vs^2*Rr./s2)./...
         ((Rs + Rr./s2).^2 + (Xs + Xr)^2);
T3 = (3/omega3)*(Vs^2*Rr./s3)./...
         ((Rs + Rr./s3).^2 + (Xs + Xr)^2);
plot(T1, omega11,'k-','linewidth',1.5);
hold on;
plot(T2, omega22,'k--','linewidth',1.5);
grid on;
plot(T3, omega33,'k:','linewidth',1.5);
grid on;
hold on;
axis([0 90 0 350]);
xlabel('T (N.m)');
ylabel('omega (rad/giay)');
legend('p1 = 1 ','p2 = 2','p3 = 3');                       
