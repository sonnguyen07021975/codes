clc;                
clear;              
Pn = 2200;
Vn = 400;        
nn = 2880;
p = 1;
fn = 50;            
Rs = 1.99;           
Rr = 1.84;           
Lls = 0.0111;       
Llr = 0.0115;   
Lm = 0.369;    
Ls = Lm+Lls;  
Lr = Lm+Llr;  
J = 0.002159;  
B = 0;            
TL = 5.5;       
Ts = 0.0001;
Vs = 231;                      
Xs = (2*pi*fn)*Lls;      
Xr = (2*pi*fn)*Llr;
omega1 = 2*pi*fn/p;       
omega = [0:1:320];  
s = (omega1 - omega)/omega1;
Vs0 = Vs;
Vs1 = 0.8*Vs;
Vs2 = 0.6*Vs;
T = (3/omega1)*(Vs^2*Rr./s)./...
        ((Rs + Rr./s).^2 + (Xs + Xr)^2);
T1 = (3/omega1)*(Vs1^2*Rr./s)./...
        ((Rs + Rr./s).^2 + (Xs + Xr)^2);
T2 = (3/omega1)*(Vs2^2*Rr./s)./...
        ((Rs + Rr./s).^2 + (Xs + Xr)^2);
 
plot(T,omega,'k-','linewidth',1.5);
grid on;
xlabel('s');
ylabel('T (N.m)');
hold on;
plot(T1,omega,'k--','linewidth',1.5);
grid on;
xlabel('T (N.m)');
ylabel('omega (rad/giay)');
hold on;
plot(T2,omega,'k:','linewidth',1.5);
grid on;
xlabel('T (N.m)');
ylabel('Omega (rad/giay)');
legend('Vs0','Vs1','Vs2(Vs2<Vs1<Vs0)');
axis([0 30 0 320]);
V = [Vs0 Vs1 Vs2];                                                           
sc = Rr/sqrt(Rs^2 + (Xs + Xr)^2);                                     
Tc = 3*V.^2/2/omega1/...
        (Rs + sqrt(Rs^2 + (Xs + Xr)^2));
omega_c = (1 - sc)*omega1;                                              
