clc;                
clear;              
Pn = 2200;
Vn = 400;        
nn = 2880;
p = 1;
fn = 50;            
Rs = 1.99;           
Rr = 1.84;           
Lls = 0.0111;       
Llr = 0.0115;   
Lm = 0.369;    
Ls = Lm+Lls;  
Lr = Lm+Llr;  
J = 0.002159;  
B = 0;            
TL = 5.5;       
Ts = 0.00001;
Vs = 231;                      
Xs = (2*pi*fn)*Lls;      
Xr = (2*pi*fn)*Llr;
omega1 = 2*pi*fn/p;       
omega = [0:1:320];  
s = (omega1 - omega)/omega1;
Rs0 = Rs;
Rsc = 1;
Rs1 = Rs0 + Rsc;
Rs2 = Rs1 + Rsc;
T = (3/omega1)*(Vs^2*Rr./s)./ ...
        ((Rs + Rr./s).^2 + (Xs + Xr)^2);
T1 = (3/omega1)*(Vs^2*Rr./s)./ ...
        ((Rs1 + Rr./s).^2 + (Xs + Xr)^2);
T2 = (3/omega1)*(Vs^2*Rr./s)./ ...
        ((Rs2 + Rr./s).^2 + (Xs + Xr)^2);
plot(T,omega,'k-','linewidth',1.5);
grid on;
xlabel('s');
ylabel('T (N.m)');
hold on;
plot(T1,omega,'k--','linewidth',1.5);
grid on;
xlabel('T (N.m)');
ylabel('omega (rad/iay)');
hold on;
plot(T2,omega,'k:','linewidth',1.5);
grid on;
xlabel('T (N.m)');
ylabel('omega (rad/giay)');
legend('Rs0,Rsc = 0','Rs1','Rs2>Rs1');
axis([0 30 0 320]);
R = [Rs0 Rs1 Rs2];   
sc0 = Rr/sqrt(Rs0^2 + (Xs + Xr)^2);
sc1 = Rr/sqrt(Rs1^2 + (Xs + Xr)^2);
sc2 = Rr/sqrt(Rs2^2 + (Xs + Xr)^2);
Tc0 = 3*Vs^2/2/omega1/...
         (Rs0 + sqrt(Rs0^2 + (Xs + Xr)^2));
Tc1 = 3*Vs^2/2/omega1/...
          (Rs1 + sqrt(Rs1^2 + (Xs + Xr)^2)); 
Tc2 = 3*Vs^2/2/omega1/...
          (Rs2 + sqrt(Rs2^2 + (Xs + Xr)^2));
omega_c0 = (1 - sc0)*omega1; 
omega_c1= (1 - sc1)*omega1; 
omega_c2 = (1 - sc2)*omega1;                                             
