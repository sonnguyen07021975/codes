clc;                
clear;              
Pn = 2200;
Vn = 400;        
nn = 2880;
p = 1;
fn = 50;            
Rs = 1.99;           
Rr = 1.84;           
Lls = 0.0111;       
Llr = 0.0115;   
Lm = 0.369;    
Ls = Lm+Lls;  
Lr = Lm+Llr;  
J = 0.002159;  
B = 0;            
TL = 5.5;       
Ts = 0.0001;
Vs = 231;                      
Xs = (2*pi*fn)*Lls;      
Xr = (2*pi*fn)*Llr;
omega1 = 2*pi*fn/p;       
omega = [0:1:320];  
s = (omega1 - omega)/omega1;
Xs0 = Xs;
Xsc = 1.7;
Xs1 = Xs0 + Xsc;
Xs2 = Xs1 + Xsc;
T = (3/omega1)*(Vs^2*Rr./s)./ ...
        ((Rs + Rr./s).^2 + (Xs0 + Xr)^2);
T1 = (3/omega1)*(Vs^2*Rr./s)./ ...
        ((Rs + Rr./s).^2 + (Xs1 + Xr)^2);
T2 = (3/omega1)*(Vs^2*Rr./s)./ ...
        ((Rs + Rr./s).^2 + (Xs2 + Xr)^2);
plot(T,omega,'k-','linewidth',1.5);
grid on;
xlabel('s');
ylabel('T (N.m)');
hold on;
plot(T1,omega,'k--','linewidth',1.5);
grid on;
xlabel('T (N.m)');
ylabel('omega (rad/giay)');
hold on;
plot(T2,omega,'k:','linewidth',1.5);
grid on;
xlabel('T (N.m)');
ylabel('omega (rad/giay)');
legend('Xs0,Xsc = 0','Xs1','Xs2>Xs1');
axis([0 30 0 320]);
X = [Xs0 Xs1 Xs2];   
sc0 = Rr/sqrt(Rs^2 + (Xs0 + Xr)^2);
sc1 = Rr/sqrt(Rs^2 + (Xs1 + Xr)^2);
sc2 = Rr/sqrt(Rs^2 + (Xs2 + Xr)^2);
Tc0 = 3*Vs^2/2/omega1/...
         (Rs + sqrt(Rs^2 + (Xs0 + Xr)^2));
Tc1 = 3*Vs^2/2/omega1/...
          (Rs + sqrt(Rs^2 + (Xs1 + Xr)^2)); 
Tc2 = 3*Vs^2/2/omega1/...
          (Rs + sqrt(Rs^2 + (Xs2 + Xr)^2));
omega_c0 = (1 - sc0)*omega1; 
omega_c1= (1 - sc1)*omega1; 
omega_c2 = (1 - sc2)*omega1;