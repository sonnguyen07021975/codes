clc;                        % Xoa thong tin Command Window
clear;                      % Xoa thong tin Workspace
Ra = 7.55;                  % Dien tro phan ung (Ohm)
Va = 220;                   % Dien ap phan ung (V)
K = 0.8704;                 % He so phu thuoc cau tao cua dong co (V/rad/s)
beta1 = -K*K/Ra;            % Do cung dac tinh co tu nhien (N.m.s)
T = [0:0.5:3.5];            % Vecto mo men tai (N.m)
omega1 = Va/K - Ra.*T/K/K;  % Vecto toc do (rad/s)
plot(T,omega1,'ko-','linewidth',1.5);
axis([0 max(T) 0 1.2*max(omega1)]);
grid on;
hold on;
Rf = 25;                    % Dien tro phu (Ohm)
beta2 = -K*K/(Ra + Rf);     % Do cung dac tinh co nhan tao (N.m.s) 
omega2 = Va/K - (Ra + Rf).*T/K/K;  %Vecto toc do (rad/s)
plot(T,omega2,'ko--','linewidth',1.5);
xlabel('T (N.m)');
ylabel('omega (rad/s)');
axis([0 max(T) 0 1.2*max(omega2)]);
grid on;
legend('Dac tinh co tu nhien','Dac tinh co nhan tao');








