clc;
t = data.time;
n = data.signals.values(:,1);
subplot(3,1,1);
plot(t,n,'k-','linewidth',1.5);
axis([0 max(t) 1.2*min(n) 1.2*max(n)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('n (vong/phut)');
subplot(3,1,2);
ia = data.signals.values(:,2);
plot(t,ia,'k-','linewidth',1.5);
axis([0 max(t) 1.2*min(ia) 1.2*max(ia)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('ia (A)');
subplot(3,1,3);
T = data.signals.values(:,3);
plot(t,T,'k-','linewidth',1.5);
axis([0 max(t) 1.2*min(T) 1.2*max(T)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('T (N.m)');


