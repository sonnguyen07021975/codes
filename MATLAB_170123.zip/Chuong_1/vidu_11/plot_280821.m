clc;
t = data.time;
V = data.signals.values(:,1);
subplot(4,1,1);
plot(t,V,'k-','linewidth',1.5);
axis([0 max(t) 0 1.2*max(V)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('Va (V)');

subplot(4,1,2);
ia = data.signals.values(:,2);
plot(t,ia,'k-','linewidth',1.5);
axis([0 max(t) 1.2*min(ia) 1.2*max(ia)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('ia (A)');

subplot(4,1,3);
Te = data.signals.values(:,3);
plot(t,Te,'k-','linewidth',1.5);
axis([0 max(t) 1.2*min(Te) 1.2*max(Te)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('Te (N.m)');

subplot(4,1,4);
speed = data.signals.values(:,4);
plot(t,speed,'k-','linewidth',1.5);
axis([0 max(t) 1.2*min(speed) 1.2*max(speed)]);
grid on;
xlabel('Thoi gian (s)');
ylabel('n (rad/s)');


