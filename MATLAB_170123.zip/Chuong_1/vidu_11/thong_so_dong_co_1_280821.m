clc;                % Xoa thong tin Command Window
clear;              % Xoa thong tin Workspace
Pr = 750;           % Cong suat dong co (W)
Ra = 7.55;          % Dien tro phan ung (Ohm)
La = 0.1114;        % Dien cam phan ung (H)
K = 0.8704;         % He so phu thuoc cau tao cua dong co (V/rad/s)
J = 0.01287;        % Momen quan tinh (kg.m^2)
B = 0.0001;         % He so ma sat (N.m.s)
Va = 220;           % Dien ap phan ung (V)
nr = 2000;          % Toc do dinh muc (vong/phut)
TL = Pr/nr*30/pi;   % Momen tai dinh muc (N.m)

