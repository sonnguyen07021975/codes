clc;                        % Xoa thong tin Command Window
clear;                      % Xoa thong tin Workspace
Ra = 7.55;                  % Dien tro phan ung (Ohm)
Va = 220;                   % Dien ap phan ung (V)
K = 0.8704;                 % He so phu thuoc cau tao cua dong co (V/rad/s)
beta = -K*K/Ra;             % Do cung dac tinh co (N.m.s)
T = [0:0.5:3.5];            % Vecto mo men tai (N.m)
omega = Va/K - Ra.*T/K/K;   % Vecto toc do dong co (rad/s)
plot(T,omega,'ko-','linewidth',1.5);
xlabel('T (N.m)');
ylabel('omega (rad/s)');
axis([0 max(T) 0 1.2*max(omega)]);
grid on;








