clc;                        % Xoa thong tin Command Window
clear;                      % Xoa thong tin Workspace
Ra = 7.55;                  % Dien tro phan ung (Ohm)
K = 0.8704;                 % He so phu thuoc cau tao cua dong co (N.m/A)
Va1 = 220;                  % Dien ap phan ung (V)
beta = -K*K/Ra;             % Do cung
T = [0:0.5:3.5];            % Vecto mo men (N.m)
omega1 = Va1/K - Ra.*T/K/K; % Vecto toc do (rad/s)
plot(T,omega1,'ko-','linewidth',1.5);
hold on;
Va2 = 110;                   % Dien ap phan ung (V)
omega2 = Va2/K - Ra.*T/K/K;  % Vecto toc do (rad/s)
plot(T,omega2,'ko--','linewidth',1.5);
xlabel('T (N.m)');
ylabel('omega (rad/s)');
axis([0 max(T) 0 1.2*max(omega1)]);
grid on;
legend('Dac tinh co tu nhien','Dac tinh co nhan tao');

